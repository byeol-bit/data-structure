package topological;
import java.io.*;
import java.util.Scanner;

public class TopologicalSort 
{

	public static void main(String[] args)
	{
		
		try 
		{
			String fileName = "";
			Scanner sc = new Scanner(System.in);
		
			System.out.print("���� �׷����� ����� ���ϸ��� �Է��Ͻÿ�(����� quit): ");
			fileName = sc.nextLine();
			DirectedGraph dg = new DirectedGraph();
			dg.loadFile(fileName);
			dg.show();
			dg.topologicalSort();
			sc.close();
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("IOException");
		}
		
	}

}
