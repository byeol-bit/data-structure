package topological;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

class DirectedGraph
{
	private int[][] adjArr = null;
	private int vertexSize;
	private int[] count;
	public DirectedGraph()
	{
		vertexSize = 0;
	}
	
	public void loadFile(String fileName) throws IOException
	{
		FileInputStream in = new FileInputStream(fileName);
		Scanner sc = new Scanner(in);
		int n;
		int m;
		
		n = sc.nextInt();
		if(n < 0)
		{
			System.out.println( "vertex 0���� Ŀ���մϴ�");
		}
		vertexSize = n;
		count = new int[vertexSize];
		adjArr =new int[vertexSize][]; 
		for(int i = 0; i < vertexSize; i++)
		{
			count[i] = 0;
			adjArr[i] = new int[vertexSize];
			for(int j = 0; j < vertexSize; j++)
			{
				adjArr[i][j] = 0;
			}
		}
		while(true)
		{
			n = sc.nextInt();
			if(n == -1)
			{
				break;
			}
			m = sc.nextInt();
			adjArr[n][m] = 1;
			count[m]++;
		}
		sc.close();
	}
	public void show()
	{
		System.out.println("�������");
		for(int i = 0; i < vertexSize; i++)
		{
			
			for(int j = 0; j < vertexSize; j++)
			{
				System.out.print(adjArr[i][j]);
			}
			System.out.println();
		}
		
	}
	public void topologicalSort()
	{
		System.out.print("������ �ϳ��� �������� : ");
		boolean visited[] = new boolean[vertexSize];
		int n = 0;
		int check = 0;
		for(int i = 0; i < vertexSize; i++)
		{
			visited[i] = false;
		}
		
		
		while(true)
		{
			check = 0;
			for(n = 0; n < vertexSize; n++)
			{
				if(count[n] == 0)
				{
					System.out.print(n + " ");
					count[n] = -1;
					for(int i = 0; i < vertexSize; i++)
					{
						if(adjArr[n][i] == 1)
						{
							count[i]--;
						}
						
					}
				}
			}
			for(int j = 0; j < vertexSize; j++)
			{
				if(count[j] == -1)
				{
					check++;
				}
			}
			if(check == vertexSize)
			{
				break;
			}
			else if(n == vertexSize)
			{
				n = 0;
			}
		}
	}
}

