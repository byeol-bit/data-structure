#include "MinHeap.h"

MinHeap::MinHeap()
{
	heapSize = 0;
	capacity = 100;
	heap = new Vertex[capacity+1];
}
void MinHeap::push(int vertex1, int vertex2, int weight)
{

	if (heapSize == capacity)
	{
		changeSize1D();
	}
	
	int currentNode = ++heapSize;

 	while (currentNode != 1 && heap[currentNode / 2].weight > weight)
	{
		heap[currentNode] = heap[currentNode / 2];
		currentNode /= 2;
	}
	heap[currentNode] = {vertex1, vertex2, weight };
}

void MinHeap::pop()
{
	if (isEmpty())
	{
		cout << " �ּ� ������ ����� �ֽ��ϴ�. ";
		return;
	}

	heap[1].~Vertex();

	Vertex lastData = heap[heapSize--];
	int currentNode = 1;
	int child = 2;

	while (child <= heapSize)
	{
		if (child < heapSize && heap[child].weight > heap[child + 1].weight){child++;}
		if (lastData.weight <= heap[child].weight)	{break;}

		heap[currentNode] = heap[child];
		currentNode = child;
		child *= 2;
	}
	heap[currentNode] = lastData;
}



void MinHeap::changeSize1D()
{
	Vertex* temp = new Vertex[capacity * 2];
	capacity *= 2;

	for (int i = 0; i < heapSize + 1; i++)	{temp[i] = heap[i];}
	delete[] heap;
	heap = temp;

	return;
}

bool MinHeap::isEmpty()
{
	if (heapSize == 0)	{	return true;	}
	return false;
}

void MinHeap::printHeap()
{
	for (int i = 1; i < heapSize + 1; i++)
	{
		cout << heap[i].vertex1 << " ";
		cout << heap[i].vertex2 << " ";
		cout << heap[i].weight << " ";
		cout << endl;
	}
}