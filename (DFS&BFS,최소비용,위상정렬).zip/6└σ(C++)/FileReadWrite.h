#pragma once
#include <iostream>
#include <fstream>
#include "LinkedGraph.h"
#include "UnLinkedGraph.h"
#include "MinHeap.h"
#include "Topological.h"
using namespace std;

class FileReadWrite
{
public:
	void readS(string str, LinkedGraph& lg);

	void readM(string str, MinHeap& minheap, UnLinkedGraph& ulg);

	void readT(string str, Topological&  topol);

	FileReadWrite() {}
	~FileReadWrite() {}
};

