#pragma once
#include <iostream>
using namespace std;

class Set
{
private:
	int *parent;
	int n;			// ���� ������ ����
public:
	Set(int numberOfElements)
	{
		if (numberOfElements < 2) cout << "Must have at least 2 elements";
		n = numberOfElements;
		parent = new int[n];
		fill(parent, parent + n, -1);
	}
	~Set();

	void weightedUnion(int i, int j);
	int collapsingFind(int n);
};

