#include "Chain.h"



Chain::Chain()
{
	first = NULL;
}


Chain::~Chain()
{
}
