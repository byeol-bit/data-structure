#pragma once
#include <iostream>
using namespace std;

class MinHeap
{
	typedef struct Vertex
	{
		int vertex1;	// ����1
		int vertex2;	// ����2
		int weight;		// ����ġ
	}Vertex;
public:
	MinHeap();
	~MinHeap() {}

	int getHeapSize() { return heapSize; }
	Vertex getHeap() { return heap[1]; }
	void push(int vertex1, int vertex2, int weight);
	void pop();


	void changeSize1D();
	bool isEmpty();
	void printHeap();

private:
	Vertex* heap;
	int heapSize;
	int capacity;
};

