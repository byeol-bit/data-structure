#include "ChainNode.h"


ChainNode::ChainNode(int coef, int exp, ChainNode* next)
{
	this->exp = exp;
	this->coef = coef;
	link = next;
}

ChainNode::ChainNode()
{
	link = 0;
}


ChainNode::~ChainNode()
{
}