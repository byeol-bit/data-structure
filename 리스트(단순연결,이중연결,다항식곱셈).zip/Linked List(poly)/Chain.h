#pragma once
#include "ChainNode.h"
#include <string>
#include <iostream>
using namespace std;

class Chain
{
private:
	ChainNode* first;
public:
	Chain();
	~Chain();

	void insert(int coef, int exp);
	void deleteNode(ChainNode* x);
	Chain multify(Chain& c);
	void displayStudents();

	ChainNode* getFirst() { return first; }
	void setFirst(ChainNode* x) { first = x; }
	
	Chain operator+(Chain &c);
	friend istream& operator >> (istream& is, Chain &c);
};
