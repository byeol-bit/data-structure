#include "Chain.h"

Chain::Chain()
{
	first = NULL;
}

Chain::~Chain()
{
}

void Chain::insert(int coef, int exp)
{
	if (coef == 0 && exp == 0) {}
	else if (first != NULL)
	{
		ChainNode* privious = first;
		ChainNode* current = new ChainNode(coef, exp, 0);

		while (privious->getLink() != NULL)
		{
			privious = privious->getLink();
		}

		privious->link = current;
	}
	else
	{
		first = new ChainNode(coef, exp, 0);
	}
}


void Chain::deleteNode(ChainNode* x)
{
}

Chain Chain::multify(Chain& c)
{
	Chain b;
	ChainNode* point = first;
	
	for (;point != NULL;)
	{
		Chain a;
		ChainNode* op = c.getFirst();

			for (; op != NULL;)
			{
				// ������� ��
				int num1 = point->getCoef() * op->getCoef();
				// �������� ��
				int num2 = point->getExp() + op->getExp();

				// ���� ��� ��
				a.insert(num1, num2);
				op = op->getLink();
			}
		point = point->getLink();

		b = b + a;
	}
	return b;
}

Chain Chain::operator+(Chain &c)
{
	Chain a;
	ChainNode* aPos = first;
	ChainNode* bPos = c.first;

	while (aPos != NULL && bPos != NULL)
	{
		if (aPos->getExp() == bPos->getExp())
		{
			int sum = aPos->getCoef() + bPos->getCoef();
			if (sum) a.insert(sum, aPos->getExp());

			aPos = aPos->getLink();
			bPos = bPos->getLink();
		}
		else if (aPos->getExp() < bPos->getExp())
		{
			a.insert(bPos->getCoef(), bPos->getExp());
			bPos = bPos->getLink();
		}
		else
		{		
			a.insert(aPos->getCoef(), aPos->getExp());
			aPos = aPos->getLink();
		}
	}

	while (aPos != NULL)
	{
		a.insert(aPos->getCoef(), aPos->getExp());
		aPos = aPos->getLink();
	}
	while (bPos != NULL)
	{
		a.insert(bPos->getCoef(), bPos->getExp());
		bPos = bPos->getLink();
	}
	return a;
}

void Chain::displayStudents()
{
	ChainNode* current = getFirst();

	// ��尡 �Ѱ��� ���� ��
	if (current == NULL)
	{
		cout << "����� ��尡 �����ϴ�." << endl;
		return;
	}
	else
	{
		while (current != NULL)
		{
			if (current->getCoef() == 1) 
			{
				if (current->getExp() == 0)
					cout << 1;
				else if (current->getExp() == 1)
					cout << "x";
				else
					cout << "x^" << current->getExp();

				if (current->getLink() == NULL) {}
				else cout << " + ";

			}
			else
			{
				if (current->getExp() == 0) 
				{
					cout << current->getCoef();
				}
				else if (current->getExp() == 1)
				{
					if (current->getCoef() == -1)
					{
						cout << "-x";
					}
					else
					{
						cout << current->getCoef();
						cout << "x";
					}
				}
				else
				{
					if (current->getCoef() == -1)
					{
						cout << "-x^" << current->getExp();
					}
					else
					{
						cout << current->getCoef();
						cout << "x^" << current->getExp();
					}
				}

				if (current->getLink() == NULL) {}
				else cout << " + ";
			}
			current = current->getLink();
		}
	}
}

istream& operator >> (istream& is, Chain &c)
{
	int a = 0, b = 1;

	while (b != 0)
	{
		is >> a >> b;
		c.insert(a, b);
	}
	return is;
}