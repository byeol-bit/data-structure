#pragma once
#include <iostream>
#include <string>
using namespace std;

class ChainNode
{
	friend class Chain;
private:
	int coef;
	int exp;
	ChainNode* link;
public:
	ChainNode();
	~ChainNode();
	ChainNode(int coef, int exp, ChainNode* next);
	int getExp() { return exp; }
	int getCoef() { return coef; }
	ChainNode* getLink() { return link; }

	void setExp(int x) { exp = x; }
	void setCoef(int x) { coef = x; }
	void setLink(ChainNode* x) { link = x; }
};
