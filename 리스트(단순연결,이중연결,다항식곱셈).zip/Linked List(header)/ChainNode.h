#pragma once
#include <iostream>
#include <string>
using namespace std;

class ChainNode
{
	friend class Chain;
private:
	string name;
	long number;
	ChainNode* link;
public:
	ChainNode();
	~ChainNode();
	ChainNode(long number, string name, ChainNode* next);
	string getName() { return name; }
	long getNumber() { return number; }
	ChainNode* getLink() { return link; }
	void setLink(ChainNode* x) { link = x; }
};
