#include "FileManager.h"


FileManager::FileManager(void)
{
}


FileManager::~FileManager(void)
{
}

void FileManager::loadFile(Chain& c, string s)
{

	ifstream fin;
	fin.open(s, ios_base::in);
	if (fin.fail())
		throw "���� ���� ����";

	string name; long number;

	while (!fin.eof())
	{
		fin >> number >> name;
		c.insert(name, number);
	}
	fin.close();
}

void FileManager::saveFile(Chain& c, string s)
{
	ofstream fout;
	long id;
	string name;
	ChainNode* current = c.getFirst();

	fout.open(s, ios_base::out);

	if (fout.fail())
		throw "���� ���� ����";
	if (current->getLink() == NULL)
	{
		fout << "";
	}
	else
	{
		while (current->getLink() != NULL)
		{
			current = current->getLink();

			id = current->getNumber();
			name = current->getName();

			if(current->getLink() == NULL)
				fout << id << " " << name;
			else
				fout << id << " " << name << endl;

			if (current->getLink() == NULL)
			{
				break;
			}
		}
	}

	fout.close();
}