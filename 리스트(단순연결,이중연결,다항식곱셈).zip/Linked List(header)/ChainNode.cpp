#include "ChainNode.h"


ChainNode::ChainNode(long number, string name, ChainNode* next)
{
	this->name = name;
	this->number = number;
	link = next;
}

ChainNode::ChainNode()
{
}


ChainNode::~ChainNode()
{
}