#include "Chain.h"


Chain::Chain()
{
	first = new ChainNode(0, "header", 0);
}

Chain::~Chain()
{
	delete first;
	delete last;
}

void Chain::insert(string name, long number)
{
		ChainNode* privious = first;
		ChainNode* current = new ChainNode(number, name, 0);


		if (privious->getNumber() <= current->getNumber())
		{
			while (privious->getNumber() <= current->getNumber())
			{
				if (privious->link == NULL)
				{
					privious->link = current;
					break;
				}

				ChainNode* temp = privious;
				privious = privious->link;

				if (current->getNumber() < privious->getNumber())
				{
					current->setLink(privious);
					temp->setLink(current);
					break;
				}
			}
		}
}

void Chain::deleteNode(ChainNode* x)
{
	delete x;
}