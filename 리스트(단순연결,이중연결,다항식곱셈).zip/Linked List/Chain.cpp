#include "Chain.h"

ChainNode::ChainNode(long number, string name, ChainNode* next)
{
	this->name = name;
	this->number = number;
	link = next;
}

ChainNode::ChainNode()
{
}


ChainNode::~ChainNode()
{
}

Chain::Chain()
{
	first = NULL;
}

Chain::~Chain()
{
	delete first;
	delete last;
}

void Chain::insert(string name, long number)
{
	if (first != NULL)
	{
		ChainNode* privious = first;
		ChainNode* current = new ChainNode(number, name, 0);

		if (current->getNumber() < privious->getNumber())
		{
			current->link = privious;
			first = current;
		}
		else if (privious->getNumber() <= current->getNumber())
		{
			while (privious->getNumber() <= current->getNumber())
			{
				if (privious->link == NULL)
				{
					privious->link = current;
					break;
				}
				ChainNode* temp = privious;
				privious = privious->link;

				if (current->getNumber() < privious->getNumber())
				{
					current->setLink(privious);
					temp->setLink(current);
					break;
				}
			}
		}
	}
	else
	{
		first = new ChainNode(number, name, 0);
		last = first;
	}
}

void Chain::deleteNode(ChainNode* x)
{ 
	delete x; 
}