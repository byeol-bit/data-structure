#pragma once
#include <iostream>
#include <string>
#include "FileManager.h"
#include "Chain.h"
using namespace std;

class StudentManager
{
public:
	StudentManager();
	~StudentManager();

	void insertStudent(Chain& c);
	void deleteStudnet(Chain& c);
	void displayStudents(Chain& c);
	void theEnd();

};