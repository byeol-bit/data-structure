#pragma once
#include <iostream>
#include <string>
using namespace std;

class Chain;

class ChainNode
{
friend class Chain;
private:
	string name;
	long number;
	ChainNode* link;
public:
	ChainNode();
	~ChainNode();
	ChainNode(long number, string name, ChainNode* next);
	string getName() { return name; }
	long getNumber() { return number; }
	ChainNode* getLink() { return link; }
	void setLink(ChainNode* x) { link = x; }
};

class Chain
{
private:
	ChainNode* first;
	ChainNode* last;
public:
	Chain();
	~Chain();
	void insert(string name, long number);
	void deleteNode(ChainNode* x);
	ChainNode* getLast() { return last; }
	ChainNode* getFirst() { return first; }
	void setFirst(ChainNode* x) { first = x; }
};

