#pragma once
#include <iostream>
#include <string>
#include "Chain.h"
using namespace std;

class FileManager
{
public:
	FileManager();
	~FileManager();

	void saveFile(Chain& c, string s);
	void loadFile(Chain& c, string s);
};

