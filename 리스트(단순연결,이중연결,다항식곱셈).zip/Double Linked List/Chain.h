#pragma once
#include <iostream>
#include <string>
#include "ChainNode.h"
using namespace std;

class Chain
{
private:
	ChainNode* first;
	ChainNode* last;
public:
	Chain();
	~Chain();
	void insert(string name, long number);
	void deleteNode(ChainNode* x);
	ChainNode* getLast() { return last; }
	ChainNode* getFirst() { return first; }
	void setFirst(ChainNode* x) { first = x; }
	void setLast(ChainNode* x) { last = x; }
};
