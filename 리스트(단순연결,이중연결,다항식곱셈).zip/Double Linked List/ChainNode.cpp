#include "ChainNode.h"

ChainNode::ChainNode(long number, string name, ChainNode* front, ChainNode* next)
{
	this->name = name;
	this->number = number;
	this->front = front;
	this->next = next;
}

ChainNode::ChainNode() {}
ChainNode::~ChainNode() {}