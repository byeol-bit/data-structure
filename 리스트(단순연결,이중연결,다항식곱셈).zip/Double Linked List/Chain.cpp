#include "Chain.h"

Chain::Chain()
{
	first = NULL;
	last = NULL;
}

Chain::~Chain()
{
	delete first;
	delete last;
}

void Chain::insert(string name, long number)
{
	if (first != NULL)
	{
		ChainNode* privious = first;
		ChainNode* current = new ChainNode(number, name, 0, 0);

		if (current->getNumber() < privious->getNumber())
		{
			current->next = privious;
			privious->setFront(current);
			first = current;
		}

		else if (privious->getNumber() <= current->getNumber())
		{
			while (privious->getNumber() <= current->getNumber())
			{
				if (privious->next == NULL)
				{
					privious->next = current;
					current->setFront(privious);
					last = current;
					break;
				}
				privious = privious->next;

				if (current->getNumber() < privious->getNumber())
				{
					current->setNext(privious);
					privious->getFront()->setNext(current);
					privious->setFront(current);
					current->setFront(privious->getFront());
					break;
				}
			}
		}
	}
	else
	{
		first = new ChainNode(number, name, last , 0);
		last = first;
	}
}

void Chain::deleteNode(ChainNode* x)
{
	delete x;
}