#pragma once
#include <iostream>
#include <string>
using namespace std;

class ChainNode
{
	friend class Chain;
private:
	string name;
	long number;
	ChainNode* front;
	ChainNode* next;
public:
	ChainNode();
	~ChainNode();
	ChainNode(long number, string name, ChainNode* front, ChainNode* next);
	string getName() { return name; }
	long getNumber() { return number; }
	ChainNode* getFront() { return front; }
	ChainNode* getNext() { return next; }
	void setFront(ChainNode* x) { front = x; }
	void setNext(ChainNode* x) { next = x; }
};
