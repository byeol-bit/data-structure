#pragma once
#include <iostream>
using namespace std;

template<class T>
class Stack
{
private:
	T* stack;
	int top;
	int capacity;
public:
	Stack();
	~Stack();

	bool isEmpty() const;

	T& getTop();

	void push(const T& item);
	void pop();

	void changeSize1D();

};


template<class T>
Stack<T>::Stack()
{
	capacity = 1024;
	top = -1;
	stack = new T[capacity];
}

template<class T>
Stack<T>::~Stack()
{
}

template<class T>
bool Stack<T>::isEmpty() const { return top == -1; }

template<class T>
T& Stack<T>::getTop()
{
	if (isEmpty())
		cout << "������ ��Ŷ�ķ�~";
	return stack[top];
}



template<class T>
void Stack<T>::push(const T& item)
{
	if (top == capacity - 1)
	{
		changeSize1D();
	}
	stack[++top] = item;
}

template<class T>
void Stack<T>::pop()
{
	if (isEmpty())
		cout << "���� ���ֺ������";
	stack[top--].~T();
}

template<class T>
void Stack<T>::changeSize1D()
{
	T *temp;
	temp = new T[2 * capacity];
	capacity *= 2;
	copy(stack, stack + capacity, temp);

	delete[] stack;
	stack = temp;

	return;

}