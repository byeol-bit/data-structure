#include <iostream>
#include "TreeNode.h"
using namespace std;

int main()
{
	int number = 0; // ��� ����
	cout << "��� ������ �Է��ϼ��� : ";
	cin >> number;

	BinaryTree<int> completeBTree;
	completeBTree.insert(number);

	completeBTree.print();
	cout << endl;

	cout << "preorder : ";
	completeBTree.preOrder();
	cout << endl <<"inorder : ";
	completeBTree.inOrder();
	cout << endl << "postorder : ";
	completeBTree.postOrder();
	cout << endl << "levelorder : ";
	completeBTree.levelOrder();

	return 0;
}