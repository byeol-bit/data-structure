#pragma once
#define nodeNull 0
#include <iostream>
#include <queue>

using namespace std;

template <class T> class BinaryTree;

template <class T>
class TreeNode
{
	friend class BinaryTree<T>;
private:
	T data;
	TreeNode<T>* leftChild;
	TreeNode<T>* rightChild;

public:
	TreeNode<T>()
	{
		data = nodeNull;
		leftChild = nodeNull;
		rightChild = nodeNull;
	}
};

template <class T>
class BinaryTree
{
private:
	TreeNode<T>* root;
	int currNodeNum;
public:
	BinaryTree<T>() 
	{
		currNodeNum = 0; // ��� ����
		root = new TreeNode<T>();
		root->data = 1;
		root->leftChild = nodeNull;
		root->rightChild = nodeNull;
	}
	~BinaryTree<T>() {}

	void insert(T number)
	{
		// ������ȸ ����� ����
		queue<TreeNode<T>*> q;
		TreeNode<T>* currentNode = root;
		TreeNode<T>* tmpNode;

		for(int i=1; 2*i<=number; i++)
		{
			currentNode->data = i;

			if(currentNode->leftChild == nodeNull)
			{
				if(2 * i <= number)
				{
					TreeNode<T>* tmpNode = new TreeNode<T>;
					currentNode->leftChild = tmpNode;
					tmpNode->data = 2 * i;
					q.push(currentNode->leftChild);
				}
				
			}
			if (currentNode->rightChild == nodeNull)
			{
				if (2*i +1 <= number)
				{
					TreeNode<T>* tmpNode = new TreeNode<T>;
					currentNode->rightChild = tmpNode;
					tmpNode->data = 2 * i + 1;
					q.push(currentNode->rightChild);
				}
				
			}
			// ����
			//cout << currentNode->data;

			currentNode = q.front();
			currNodeNum++;
			q.pop();
		}
	}

	// ���� Ʈ���� �����̸� true �׷��� ������ false ��ȯ
	bool isEmpty()
	{
		if (root->data == nodeNull)
			return true;
		else return false;
	}

	// ���� ����Ʈ�� ��ȯ
	T leftSubtree() { return root->leftChild->data; }

	// ������ ����Ʈ�� ��ȯ
	T rightSubtree() { return root->rightChild->data; }

	// ��Ʈ ����� ������ ��ȯ
	T rootData() { return root->data; }

	void visit(TreeNode<T>* currentNode) { cout << currentNode->data << " "; }
	
	// Driver
	void inOrder() { inOrder(root); }
	void preOrder() { preOrder(root); }
	void postOrder() { postOrder(root); }
	void levelOrder() { levelOrder(root); }

	// Work sapce
	void inOrder(TreeNode<T>* currentNode)
	{
		if(currentNode)
		{
			inOrder(currentNode->leftChild);
			visit(currentNode);
			inOrder(currentNode->rightChild);
		}
	}
	void preOrder(TreeNode<T>* currentNode)
	{
		if (currentNode)
		{
			visit(currentNode);
			preOrder(currentNode->leftChild);
			preOrder(currentNode->rightChild);
		}
	}
	void postOrder(TreeNode<T>* currentNode)
	{
		if (currentNode)
		{
			preOrder(currentNode->leftChild);
			preOrder(currentNode->rightChild);
			visit(currentNode);
		}
	}

	
	void levelOrder(TreeNode<T>* currentNode1)
	{
		queue<TreeNode<T>*> q;
		currentNode1 = root;

		while (currentNode1)
		{
			visit(currentNode1);
			if (currentNode1->leftChild) q.push(currentNode1->leftChild);
			if (currentNode1->rightChild) q.push(currentNode1->rightChild);
			if (q.empty()) return;
			currentNode1 = q.front();
			q.pop();
		}
	}
	void print()
	{	print(root); }
	void print(TreeNode<T>* currentNode1)
	{
		if (currentNode1)
		{
			int height = 1 + log2(currentNode1->data);

			if (currentNode1->data == 1)
			{
				cout << currentNode1->data;
			}
			else
			{
				if (currentNode1->data % 2)
				{
					cout << "\n ";
					if (height > 2)
						for (int i = 2; i < height; i++)
							cout << "      ";
				}

				cout << " --- " << currentNode1->data;
			}
			print(currentNode1->leftChild);
			print(currentNode1->rightChild);
		}
	}
};