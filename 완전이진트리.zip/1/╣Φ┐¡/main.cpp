#include "BTree.h"
#include <iostream>
using namespace std;

int main()
{
	int number = 0; // ��� ����
	cout << "��� ������ �Է��ϼ��� : ";
	cin >> number;

	BTree<int> BTree(number);
	BTree.insert(number);

	BTree.print();
	cout << endl;

	cout << "preorder : ";
	BTree.preOrder();
	cout << endl << "inorder : ";
	BTree.inOrder();
	cout << endl << "postorder : ";
	BTree.postOrder();
	cout << endl << "levelorder : ";
	BTree.levelOrder();

	return 0;
}