#pragma once

#include <iostream>
using namespace std;

template <class T>
class BTree
{
private:
	T* arr;
	int count;
	int start; // pre, in post�Լ��� ���������� ���ۺ���
public:
	BTree(int num)
	{
		start = 1;
		count = num;
		arr = new T[num+1];
	}

	// Driver
	void preOrder() { preOrder(start); }
	void inOrder() { inOrder(start); }
	void postOrder() { postOrder(start); }
	void print() { print(start); }

	// Work Space
	void preOrder(int start)
	{
		if (start <= count) {
			visit(start);
			preOrder(start * 2);
			preOrder((start * 2) + 1);
		}
	}
	void inOrder(int start)
	{
		if (start <= count) {
			inOrder(start * 2);
			visit(start);
			inOrder((start * 2) + 1);
		}
	}

	void postOrder(int start)
	{
		if (start <= count) {
			postOrder(start * 2);
			postOrder((start * 2) + 1);
			visit(start);
		}
	}

	void levelOrder()
	{
		for (int i = 1; i <= count; i++)
			cout << arr[i] << " ";
	}

	void visit(int number) { cout << arr[number] << " "; }

	void insert(int num)
	{
		for (int i = 0; i <= num; i++)
			arr[i] = i;
	}

	void print(int start)
	{
		int height = 1 + log2(start);

		if (start <= count) {

			if (start == 1)
			{
				cout << arr[start];
			}
			else {
				if (start % 2 != 0) {
					cout << "\n ";
					for (int i = 2; i < height; i++)
						cout << "      ";
				}
				cout << " --- " << arr[start];
			}

			print(start * 2);
			print((start * 2) + 1);
		}
	}
};