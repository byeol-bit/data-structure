#pragma once
#define nodeNull 0
#include "TreeNode.h"

template <class T>
class BSTree
{
private:
	TreeNode<T>* root;
	int currNodeNum;
public:
	BSTree()
	{
		currNodeNum = 0; // ��� ����
		root = new TreeNode<T>();
		root->data = "";
		root->leftChild = nodeNull;
		root->rightChild = nodeNull;
	}
	~BSTree() {}

	// ���� ����Ʈ�� ��ȯ
	T leftSubtree() { return root->leftChild->data; }

	// ������ ����Ʈ�� ��ȯ
	T rightSubtree() { return root->rightChild->data; }

	// ��Ʈ ����� ��ȯ
	TreeNode<T>* returnRoot() { return root; }

	void deleteNode(TreeNode<T>* currentNode) {}
	void insert(T data)
	{
		TreeNode<T>* currentNode = root;

		if (currentNode->data == "")
			currentNode->data = data;
		else if (currentNode)
		{
			while (true)
			{
				if (currentNode->data < data)
				{
					if (currentNode->rightChild)
						currentNode = currentNode->rightChild;
					else
					{
						currentNode->rightChild = new TreeNode<T>(0, data, 0);
						break;
					}
				}
				else
				{
					if (currentNode->leftChild)
						currentNode = currentNode->leftChild;
					else
					{
						currentNode->leftChild = new TreeNode<T>(0, data, 0);
						break;
					}
				}
			}
			currNodeNum++;
		}
	}

	void print(TreeNode<T>* currentNode, int rank)
	{
		int height = 1 + floor(log2(rank));

		if (currentNode)
		{
			if (rank == 1)
				cout << currentNode->data;
			else
			{
				if (rank % 2 == 1)
				{
					cout << "\n      ";
					if (height > 2)
						for (int i = 2; i < height; i++)
							cout << "           ";
				}

				cout << " --- " << currentNode->data;
			}
			print(currentNode->leftChild, rank * 2);
			if (currentNode->rightChild) cout << "--- 0";
				print(currentNode->rightChild, (rank * 2) + 1);
		}
	}
};