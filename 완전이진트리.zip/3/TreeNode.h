#pragma once
#include <iostream>
#include <string>
using namespace std;

template <class T> class BSTree;

template <class T>
class TreeNode
{
	friend class BSTree<T>;
private:
	T data;
	TreeNode<T>* leftChild;
	TreeNode<T>* rightChild;

public:
	TreeNode<T>()
	{
		data = "";
		leftChild = nodeNull;
		rightChild = nodeNull;
	}
	TreeNode<T>(TreeNode<T>* bt1, T data, TreeNode<T>* bt2)
	{
		this->data = data;
		leftChild = bt1;
		rightChild = bt2;
	}
};