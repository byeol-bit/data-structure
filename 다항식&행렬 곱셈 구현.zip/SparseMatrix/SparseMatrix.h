#pragma once
#include "MatrixTerm.h"
#include <algorithm>
#include <iostream>
using namespace std;

class SparseMatrix
{
private:
	int rows, cols, terms, capacity;
	MatrixTerm *smArray;
public:
	SparseMatrix();
	~SparseMatrix();

	SparseMatrix(int r, int c, int t);

	int getTerms() { return terms; }
	int getRows() { return rows; }
	int getCols() { return cols; }
	int getCapacity() { return capacity; }
	// ���� ��ġ �Լ� O(cols + terms)
	SparseMatrix fastTranspose();
	
	// ��� ���� ����
	void storeSum(const int r, const int c, const int sum);
	void changeSize1D(const int newSize);
	
	SparseMatrix Multiply(SparseMatrix &b);
	SparseMatrix cinMatrix(int a, int b, SparseMatrix &s); // a*b��İ� �Է¹޴� �Լ�
	friend ostream& operator << (ostream &os, SparseMatrix &s); // cout << matrix �� ���� �Լ�
};

