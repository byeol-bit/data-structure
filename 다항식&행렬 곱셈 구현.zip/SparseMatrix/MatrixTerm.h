#pragma once

class MatrixTerm
{
private:
	int row, col, value;
public :
	MatrixTerm() 
	{
		row = 0, col = 0, value = 0;
	}
	int getRow() { return row; }
	int getCol() { return col; }
	int getValue() { return value; }
	int setRow(int r) { return row = r; }
	int setCol(int c) { return col = c; }
	int setValue(int v) { return value = v; }
};

