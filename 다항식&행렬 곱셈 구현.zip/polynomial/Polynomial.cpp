#include "Polynomial.h"
#include "Term.h"
#include <iostream>
using namespace std;

Polynomial::Polynomial()
{
	capacity = 4;
	terms = 0;
	termArray = new Term[capacity];
}

Polynomial::~Polynomial(void)
{
}

Polynomial Polynomial::operator+(Polynomial &b)
{
	Polynomial c;
	int aPos = 0, bPos = 0;
	while ((aPos < terms) && (bPos < terms))
	{
		if (termArray[aPos].getExp() == b.termArray[bPos].getExp())
		{
			float t = termArray[aPos].getCoef() + b.termArray[bPos].getCoef();
			if (t) c.newTerm(t, termArray[aPos].getExp());
			aPos++; bPos++;
		}
		else if (termArray[aPos].getExp() < b.termArray[bPos].getExp())
		{
			c.newTerm(b.termArray[bPos].getCoef(), b.termArray[bPos].getExp());
			bPos++;
		}
		else {
			c.newTerm(termArray[aPos].getCoef(), termArray[aPos].getExp());
			aPos++;
		}
	}
	// *this�� ������ �׵��� �߰�
	for (; aPos < terms; aPos++)
		c.newTerm(termArray[aPos].getCoef(), termArray[aPos].getExp());

	// b(x)�� ������ �׵��� �߰�
	for (; bPos < b.terms; bPos++)
		c.newTerm(b.termArray[bPos].getCoef(), b.termArray[bPos].getExp());
	return c;
}

Polynomial Polynomial::mult(Polynomial p)
{
	Polynomial c;
	for (int i = 0; i<terms; i++)
	{
		Polynomial a;
		for (int j = 0; j<p.terms; j++)
		{
			float coef = termArray[i].getCoef()*p.termArray[j].getCoef();
			float exp = termArray[i].getExp() + p.termArray[j].getExp();
			a.newTerm(coef, exp);
		}
		c = c + a;
	}
	return c;
}

// ���ο� �� �߰�
void Polynomial::newTerm(const float theCoeff, const float theExp)
{
	//���ο� ���� termArray ���� ÷���Ѵ�
	if (terms == capacity)
	{// termArray�� ũ�⸦ 2��� Ȯ��
		capacity = capacity * 2;
		Term *temp = new Term[capacity];
		copy(termArray, termArray + terms, temp);
		delete[] termArray;
		termArray = temp;
	}
	termArray[terms].setCoef(theCoeff);
	termArray[terms++].setExp(theExp);
}

// cout
 ostream& operator << (ostream &os, Polynomial &p)
{
	for (int i = 0; i<p.terms; i++)
	{
		// ��� ���
		if (p.termArray[i].getExp() == 0)
			os << p.termArray[i].getCoef();
		
		// x^1 ���
		else if (p.termArray[i].getExp() == 1)
		{
			if (p.termArray[i].getCoef() == 1)
				os << "x";
			os << p.termArray[i].getCoef() << "x";
		}
		
		// �� �� ������ ���
		else
			os << p.termArray[i].getCoef() << "x^" << p.termArray[i].getExp();

		if (p.terms - 1 > i)
		{
			cout << " + ";
		}
	}
	return os;
}
istream& operator >> (istream& is, Polynomial &p)
{
	float a = 0, b = 1;
	while (b != 0)
	{
		is >> a >> b;
		p.newTerm(a, b);
	}
	return is;
}