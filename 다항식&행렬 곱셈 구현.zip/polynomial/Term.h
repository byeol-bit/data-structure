#pragma once
#include "Polynomial.h"
class Term
{


private:
	float coef; // ���
	float exp; // ����

public:

	Term() { coef = 0; exp = 0; }
	~Term() {}

	float getCoef() { return coef; }
	float getExp() { return exp; }

	void setCoef(float c) { coef = c; }
	void setExp(float e) { exp = e; }
};